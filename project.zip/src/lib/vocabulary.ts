/**
 * Vocabulaires fermes du dispositif.
 *
 * Source de verite UNIQUE : le schema Drizzle contraint ses colonnes avec ces
 * listes, les contrats Zod les rejouent en enum, et /api/reference les sert au
 * front. Ajouter un secteur ici suffit a le propager partout — il ne doit
 * exister aucune autre copie de ces listes dans le depot.
 */

export const SECTORS = [
  "Numérique",
  "Santé",
  "Logistique",
  "Éducation",
  "Bâtiment",
  "Commerce",
  "Industrie",
] as const;

export const CITIES = [
  "Paris",
  "Lyon",
  "Marseille",
  "Lille",
  "Nantes",
  "Bordeaux",
  "Strasbourg",
  "Toulouse",
] as const;

export const SKILLS = [
  "Communication",
  "Organisation",
  "Adaptabilité",
  "Travail en équipe",
  "Autonomie",
  "Rigueur",
  "Relation client",
  "Gestion de projet",
] as const;

/** Cycle de vie d'un profil, pilote par la moderation (CDC 2.1). */
export const PROFILE_STATUSES = ["pending", "published", "removed"] as const;

/** Suivi d'un candidat dans le pipeline d'un recruteur. */
export const CONTACT_STATUSES = [
  "À qualifier",
  "Entretien planifié",
  "Retenu",
  "Écarté",
] as const;

export const USER_ROLES = ["candidate", "recruiter", "admin"] as const;

export type Sector = (typeof SECTORS)[number];
export type City = (typeof CITIES)[number];
export type Skill = (typeof SKILLS)[number];
export type ProfileStatus = (typeof PROFILE_STATUSES)[number];
export type ContactStatus = (typeof CONTACT_STATUSES)[number];
export type UserRole = (typeof USER_ROLES)[number];

/**
 * Drizzle et Zod attendent un tuple mutable `[string, ...string[]]`, alors que
 * `as const` produit un tuple en lecture seule. Ce passe-plat evite de dupliquer
 * chaque liste sous deux formes.
 */
export function mutable<T extends readonly [string, ...string[]]>(list: T): [...T] {
  return [...list];
}

/* --- Bornes reglementaires (CDC 3.4) ------------------------------------- */

/** Plafond impose : le catalogue ne sert jamais plus de 20 profils par page. */
export const MAX_PAGE_SIZE = 20;
export const DEFAULT_PAGE_SIZE = 12;

/** Valeurs par defaut des reglages modifiables par l'administration. */
export const DEFAULT_CERTIFICATION_THRESHOLD = 70;
